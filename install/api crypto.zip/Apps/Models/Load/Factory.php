<?php

namespace Apps\Models\Load;

/**
 * Трейт Factory
 * @version 0.0.1
 * @package Apps\Models\Users
 * @generated Зорин Алексей, please DO NOT EDIT!
 * @author Зорин Алексей <zorinalexey59292@gmail.com>
 * @copyright 2022 разработчик Зорин Алексей Евгеньевич. Все права защищены.
 * Запрещено для комерческого использования без соглосования с автором проекта
 */
trait Factory
{

    public array $factory = [];

}
